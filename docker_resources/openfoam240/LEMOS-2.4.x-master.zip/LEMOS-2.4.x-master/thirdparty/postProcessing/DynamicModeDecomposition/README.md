LEMOS Rostock Extensions
====================
Application to perform Dynamic Mode Decompostion of fields.

Installation
============

1. If not already done source  ". $FOAM_SRC/LEMOS-2.4.x/bashrc"
2. Execute the Allwmake script.

Dependencies
============

1. Eigen library must be installed globally (see http://eigen.tuxfamily.org)
